# Jobsheet Week 2 — SIMPUS-Mini

CSS3 Styling Basics for a Mini Library System.

## Struktur
- index.html
- assets/css/style.css
- books/list.html
- books/add.html
- members/list.html
- members/add.html

## Cara menjalankan
Buka `index.html` di browser, atau gunakan Live Server di VS Code.

## Materi yang diterapkan
- CSS reset dan box-sizing
- Flexbox untuk header/navbar
- CSS Grid untuk statistic cards
- Styling tabel dan pseudo-class
- Styling form
- Footer
