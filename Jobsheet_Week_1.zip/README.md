# Jobsheet Week 1 - SIMPUS-Mini

Completed HTML5 mini library system based on the Week 1 jobsheet.

Files:
- index.html
- books/list.html
- books/add.html
- members/list.html
- members/add.html

Exercise completion:
1. Navigation menus are consistent across all five pages.
2. Three additional book rows were added.
3. Gender column was added to the member table.
4. Email field using input type="email" was added to the member form.

Note: This is still a static HTML skeleton. There is no CSS, JavaScript, database, or backend processing.
